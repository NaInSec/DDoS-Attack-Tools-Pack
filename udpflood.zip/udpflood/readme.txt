UDPFlood 2.00
-------------

UDPFlood is UDP packet sender. It sends out UDP packets to the specfied IP and port at a controllable rate. Packets can be made from a typed text string, a given number of random bytes or data from a file. Useful for server testing.


Version 2.0 does not represent any additional functionality to previous
versions of UDPFlood, it simply signifies the fact that UDPFlood has
been acquired by Foundstone (http://www.foundstone.com).

----------------------------------------------------------------------

http://www.foundstone.com
robin.keir@foundstone.com
