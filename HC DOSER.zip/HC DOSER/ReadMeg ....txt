-----

Before doing anything open 
"OCX" Folder and open "Registrator.exe" and register the ocx files.

Now run "HC - Client 2.6.exe"
